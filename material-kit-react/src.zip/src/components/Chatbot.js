import React, { useState } from "react";
import axios from "axios";
import { IconButton, TextField, Paper } from "@mui/material";
import ChatBubbleIcon from "@mui/icons-material/ChatBubble";
import SendIcon from "@mui/icons-material/Send";
import CloseIcon from "@mui/icons-material/Close";

const Chatbot = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { role: "user", content: input };
    setMessages([...messages, userMessage]);

    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: input }],
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.REACT_APP_OPENAI_API_KEY}`,
          },
        }
      );

      const botMessage = { role: "assistant", content: response.data.choices[0].message.content };
      setMessages([...messages, userMessage, botMessage]);
    } catch (error) {
      console.error("Error:", error);
    }

    setInput("");
  };

  return (
    <>
      {!open && (
        <IconButton
          onClick={() => setOpen(true)}
          style={{
            position: "fixed",
            bottom: "20px",
            right: "20px",
            backgroundColor: "#1976D2",
            color: "white",
          }}
        >
          <ChatBubbleIcon />
        </IconButton>
      )}

      {open && (
        <Paper
          style={{
            position: "fixed",
            bottom: "20px",
            right: "20px",
            width: "300px",
            maxHeight: "400px",
            display: "flex",
            flexDirection: "column",
            padding: "10px",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <strong>Chatbot</strong>
            <IconButton onClick={() => setOpen(false)}>
              <CloseIcon />
            </IconButton>
          </div>

          <div
            style={{
              flex: 1,
              overflowY: "auto",
              maxHeight: "300px",
              marginBottom: "10px",
            }}
          >
            {messages.map((msg, index) => (
              <div key={index} style={{ margin: "5px 0" }}>
                <strong>{msg.role === "user" ? "You: " : "Bot: "}</strong>
                {msg.content}
              </div>
            ))}
          </div>

          <div style={{ display: "flex" }}>
            <TextField
              fullWidth
              variant="outlined"
              size="small"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            />
            <IconButton onClick={sendMessage} color="primary">
              <SendIcon />
            </IconButton>
          </div>
        </Paper>
      )}
    </>
  );
};

export default Chatbot;
